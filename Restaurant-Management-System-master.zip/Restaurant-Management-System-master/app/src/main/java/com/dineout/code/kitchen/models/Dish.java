package com.dineout.code.kitchen.models;

public class Dish {
}
